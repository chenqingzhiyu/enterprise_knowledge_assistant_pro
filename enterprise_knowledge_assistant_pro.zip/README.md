
# 企业知识助手 Pro（轻量企业级）

## 特性
- 文件上传（知识沉淀）
- RAG检索增强
- 可扩展向量库
- 前端交互UI

## 启动
cd backend
pip install -r requirements.txt
uvicorn app:app --reload

打开 frontend/index.html

## 下一步建议
- 接入数据库（PostgreSQL）
- 用户登录（JWT）
- 多租户权限
- 替换OpenAI为本地模型
