
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter

class RAGEngine:
    def __init__(self):
        self.embedding = OpenAIEmbeddings()
        self.db = None

    def ingest_text(self, text):
        splitter = RecursiveCharacterTextSplitter(chunk_size=400, chunk_overlap=50)
        docs = splitter.create_documents([text])
        if self.db:
            self.db.add_documents(docs)
        else:
            self.db = FAISS.from_documents(docs, self.embedding)

    def query(self, question):
        if not self.db:
            return "请先上传知识"
        docs = self.db.similarity_search(question, k=2)
        return "\n".join([d.page_content for d in docs])
