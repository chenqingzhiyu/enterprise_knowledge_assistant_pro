
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from rag import RAGEngine

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

rag = RAGEngine()

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    content = await file.read()
    rag.ingest_text(content.decode("utf-8"))
    return {"status": "uploaded"}

@app.post("/ask")
async def ask(q: dict):
    return {"answer": rag.query(q["question"])}
